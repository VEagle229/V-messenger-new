const socket = io('https://your-render-backend-url.onrender.com');

const form = document.getElementById('chat-form');
const input = document.getElementById('input-message');
const messages = document.getElementById('messages');

form.addEventListener('submit', e => {
  e.preventDefault();
  if (input.value.trim() === '') return;

  // Apna message screen pe dikhayein
  const div = document.createElement('div');
  div.textContent = `You: ${input.value}`;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;

  // Server ko message bhejein
  socket.emit('chat message', input.value);
  input.value = '';
});

// Server se message receive karo
socket.on('chat message', msg => {
  const div = document.createElement('div');
  div.textContent = `Friend: ${msg}`;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
});